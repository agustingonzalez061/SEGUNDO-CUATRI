﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Lavadero
    {
        private List<Vehiculo> _vehiculos;
        private static float _precioAuto;
        private static float _precioCamion;
        private static float _precioMoto;
        private string _razonSocial;

        private Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }
        static Lavadero()
        {
            Random num = new Random();
            Lavadero._precioAuto = num.Next(150, 565);
            Lavadero._precioCamion = num.Next(150, 565);
            Lavadero._precioMoto = num.Next(150, 565);
        }
        public Lavadero (string Social) : this()
        {
            this._razonSocial = Social;
        }

        public string LavaderoToString
        { 
          get
          {
                string retorno = " ";
                retorno = retorno + this._razonSocial;
                retorno = retorno + " ";
                retorno = retorno + Lavadero._precioAuto;
                retorno = retorno + " ";
                retorno = retorno + Lavadero._precioCamion;
                retorno = retorno + " ";
                retorno = retorno + Lavadero._precioMoto;
                retorno = retorno + " ";
                foreach (Vehiculo item in _vehiculos)
                {
                    retorno = item.ToString();
                }
                
                return retorno;
          }
        }
        public List<Vehiculo> VehiculoP
        { get
            {
                return this._vehiculos;
            }
        }

        public double MostrarTotalFacturado()
        {
            double totalFacturado = 0;

            foreach (Vehiculo item in _vehiculos)
            {
                if(item is Auto)
                {
                    totalFacturado += Lavadero._precioAuto;
                }
                else if (item is Camion)
                {
                    totalFacturado += Lavadero._precioCamion;
                }
                else
                {
                    totalFacturado += Lavadero._precioMoto;
                }
            }
            return totalFacturado;
        }
        public double MostrarTotalFacturado(EVehiculos tipo)
        {
            double totalFacturado = 0;

            foreach (Vehiculo item in _vehiculos)
            {
                switch (tipo)
                {
                    case EVehiculos.Auto:
                        totalFacturado += _precioAuto;
                        break;
                    case EVehiculos.Moto:
                        totalFacturado += _precioMoto;
                        break;
                    case EVehiculos.Camion:
                        totalFacturado += _precioCamion;
                        break;
                    default:
                        break;
                }
            }
            return totalFacturado;
        }
        public static bool operator ==(Lavadero obj1, Vehiculo obj2)
        {
            bool valor = false;
            foreach (Vehiculo item in obj1._vehiculos)
            {
                if (item == obj2)
                {
                    valor = true;
                    break;
                }
            }
            return valor;
        }
        public static bool operator !=(Lavadero obj1, Vehiculo obj2)
        {
            return !(obj1 == obj2);
        }
        public static int operator ==(Vehiculo obj1, Lavadero obj2)
        {
            int valor = -1;
            for (int i = 0; i < obj2._vehiculos.Count; i ++)
            {
                if(obj1 == obj2._vehiculos[i])
                {
                    valor = i;
                    break;
                }
            }
            return valor;
        }
        public static int operator !=(Vehiculo obj1, Lavadero obj2)
        {
            return -1;
        }

    }
}
