﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Moto : Vehiculo
    {
        protected float _cilindrada;
        public Moto(EMarca marca,byte cantidadRuedas, string patente, float cilindrada) : base(patente, cantidadRuedas , marca)
        {
            this._cilindrada = cilindrada;
        }
        public Moto(EMarca marca, float cilindrada, string patente, byte cantidadRuedas) :this(marca, cantidadRuedas, patente,cilindrada)
        {
        }

        protected override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("MOTO");
            sb.AppendLine(base.ToString());
            sb.AppendLine("Cilindrada : " + this._cilindrada);
            sb.AppendLine("");
            sb.AppendLine("---------------------");

            return sb.ToString();
        }
        public override string ToString()
        {
            return this.Mostrar();
        }

    }
}
