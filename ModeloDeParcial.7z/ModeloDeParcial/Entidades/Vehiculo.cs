﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Vehiculo
    {
        
        protected string _patente;
        protected byte _cantRuedas;
        protected EMarca marca;

        public string Patente
        {
            get
            {
                return this._patente;
            }
        }
        public byte CantRuedas
        {
            get
            {
                return this._cantRuedas;
            }
            set
            {
                this._cantRuedas = value;
            }
        }
        public EMarca Marca
        {
            get
            {
                return this.marca;
            }
        }

        protected virtual string Mostrar()
        {
            string retorno = " ";
            retorno = retorno + this.marca;
            retorno = retorno + " ";
            retorno = retorno + this._patente;
            retorno = retorno + " ";
            retorno = retorno + this._cantRuedas;
            return retorno;
        }

        public Vehiculo(string patente, byte cantRuedas, EMarca marcas)
        {
            this._patente = patente;
            this._cantRuedas = cantRuedas;
            this.marca = marcas;
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        public static bool operator ==(Vehiculo obj1, Vehiculo obj2)
        {
            bool valor = false;
            if (!object.Equals(obj1, null) && !object.Equals(obj2, null))
            {
                if (obj1._patente == obj2._patente && obj1.marca == obj2.marca)
                {
                    valor = true;
                }
            }
            return valor;
        }
        public static bool operator !=(Vehiculo obj1, Vehiculo obj2)
        {
            return !(obj1 == obj2);
        }
    }
}

