﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Camion : Vehiculo
    {
        protected float tara;
        public Camion(string patente, EMarca marca, byte cantidadR, float tara) : base(patente, cantidadR, marca)
        {
            this.tara = tara;
        }
        public Camion(Vehiculo vehiculo, float tara) : this(vehiculo.Patente,vehiculo.Marca, vehiculo.CantRuedas, tara)
        {
        }

        protected override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("CAMION");
            sb.AppendLine(base.ToString());
            sb.AppendLine("TARA : " + this.tara);
            sb.AppendLine("");
            sb.AppendLine("---------------------");

            return sb.ToString();
        }
        public override string ToString()
        {
            return this.Mostrar();
        }
    }
}
