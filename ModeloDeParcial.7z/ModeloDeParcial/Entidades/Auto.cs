﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Auto : Vehiculo
    {
        protected int asientos;
        public Auto(string patente, EMarca marca,byte cantidadR ,int cantidadAsientos) : base(patente, cantidadR, marca)
        {
            this.asientos = cantidadAsientos;
        }
        public Auto(string patente, EMarca marca, int cantidadAsientos) : this (patente,marca, 4,cantidadAsientos)
        {
        }

        protected override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("AUTO");
            sb.AppendLine(base.ToString());
            sb.AppendLine("Asientos : " + this.asientos);
            sb.AppendLine("");
            sb.AppendLine("---------------------");

            return sb.ToString();
        }
        public override string ToString()
        {
            return this.Mostrar();
        }
    }
}
