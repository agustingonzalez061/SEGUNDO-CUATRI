﻿public enum EMarca
{
    Honda, Ford, Zanella, Scania, Iveco, fiat
}
public enum EVehiculos
{
    Auto, Moto, Camion
}