using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.RPP
{
  public class BancoProvincial : BancoNacional
  {
    public string provincia;

    public BancoProvincial (BancoNacional bancoNacional,string provincia) :base(bancoNacional.nombre,bancoNacional.pais)
    {
      this.provincia = provincia;
    }
    public override string Mostrar(Banco banco)
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendLine("Nombre");
      sb.AppendLine(this.nombre);
      sb.AppendLine("");
      sb.AppendLine("Pais");
      sb.AppendLine(this.pais);
      sb.AppendLine("");
      sb.AppendLine("Provincia");
      sb.AppendLine(this.provincia);
      sb.AppendLine("");
      sb.AppendLine("---------------------");

      return sb.ToString();
    }

    public override string Mostrar()
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendLine("Nombre");
      sb.AppendLine(this.nombre);
      sb.AppendLine("");
      sb.AppendLine("---------------------");

      return sb.ToString();
    }
  }
}
