using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.RPP
{
  public class BancoMunicipal : BancoProvincial
  {
    public string municipio;

    public BancoMunicipal (BancoProvincial bancoProvincial, string municipio):base(new BancoNacional (bancoProvincial.nombre,bancoProvincial.pais ),bancoProvincial.provincia)
    {
      this.municipio = municipio;
    }
    public override string Mostrar(Banco banco)
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendLine("Nombre");
      sb.AppendLine(this.nombre);
      sb.AppendLine("");
      sb.AppendLine("Pais");
      sb.AppendLine(this.pais);
      sb.AppendLine("");
      sb.AppendLine("Provincia");
      sb.AppendLine(this.provincia);
      sb.AppendLine("");
      sb.AppendLine("Municipio");
      sb.AppendLine(this.municipio);
      sb.AppendLine("");
      sb.AppendLine("---------------------");

      return sb.ToString();
    }

    public override string Mostrar()
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendLine("Nombre");
      sb.AppendLine(this.nombre);
      sb.AppendLine("");
      sb.AppendLine("---------------------");

      return sb.ToString();
    }
    public static implicit operator string(BancoMunicipal bancoMunicipal)
    {
      return (string)bancoMunicipal.ToString();
    }
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendLine("Nombre");
      sb.AppendLine(this.nombre);
      sb.AppendLine("");
      sb.AppendLine("Pais");
      sb.AppendLine(this.pais);
      sb.AppendLine("");
      sb.AppendLine("Provincia");
      sb.AppendLine(this.provincia);
      sb.AppendLine("");
      sb.AppendLine("Municipio");
      sb.AppendLine(this.municipio);
      sb.AppendLine("");
      sb.AppendLine("---------------------");

      return sb.ToString();
    }
  }
}
