using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Entidades.RPP
{
  public class ClaseConstructores
  {
    private string _nombre;
    private int _numero;
    static ClaseConstructores()
    {
      ClaseConstructores o = new ClaseConstructores("RPP",10);
      MessageBox.Show("Constructor static");
    }
    private ClaseConstructores (string nombre,int num) :this ()
    {
      this._numero = num;
      MessageBox.Show("Constructor de dos parametros privado");
    }
    public ClaseConstructores ()
    {
      Numero = 10;
      MessageBox.Show("Constructor por default y public");
      metodoI();
      
      
    }
    public int Numero
    {
      set
      {
        this._numero = value;
        MessageBox.Show("Propiedad de solo escritura");
        this._nombre = Nombre;
      }
    }
    public string Nombre
    {
      get
      {
        MessageBox.Show("Propiedad de solo lectura");
        return this._nombre ;
      }
    }
    public void metodoI()
    {
      MessageBox.Show("Metodo de Instancia");
      metodoS();
    }
    public static void metodoS()
    {
      MessageBox.Show("Metodo statico");
    }

  }
}
