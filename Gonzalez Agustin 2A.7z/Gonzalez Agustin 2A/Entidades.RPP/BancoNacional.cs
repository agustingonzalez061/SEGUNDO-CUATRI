using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.RPP
{
  public class BancoNacional : Banco
  {
    public string pais;

    public BancoNacional (string nombre,string pais) : base (nombre)
    {
      this.pais = pais;
    }

    public override string Mostrar(Banco banco)
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendLine("Nombre");
      sb.AppendLine(this.nombre);
      sb.AppendLine("");
      sb.AppendLine("Pais");
      sb.AppendLine(this.pais);
      sb.AppendLine("");
      sb.AppendLine("---------------------");

      return sb.ToString();
    }

    public override string Mostrar()
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendLine("Nombre");
      sb.AppendLine(this.nombre);
      sb.AppendLine("");
      sb.AppendLine("---------------------");

      return sb.ToString();
    }
  }
}
