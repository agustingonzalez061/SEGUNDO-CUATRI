using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.RPP
{
  public class Deposito
  {
    public Producto[] productos;
    public Deposito ()
    {
       productos = new Producto [3];
    }
    public Deposito(int cantidadDeProd)
    {
      productos = new Producto[cantidadDeProd];
    }
    //public static Producto operator +(Deposito d1, Deposito d2)
    //{

    //  int i, k;
    //  for (i = 0; i<d1.productos.Length;i ++)
    //  {
    //    for (k = 0; k < d2.productos.Length; k++)
    //    {
    //      if(d1.productos[i] == d2.productos [k])
    //      {
    //        d1.productos[i].stock += 1;
    //      }
    //      else
    //      {
    //        d1 += d2;
    //      }
    //    }
    //  }

    //  return d1;
    //}
  }
}
