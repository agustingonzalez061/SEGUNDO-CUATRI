using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesInterface;

namespace InterfaceTest
{
  class Program
  {
    static void Main(string[] args)
    {
      Deportivo auto1 = new Deportivo(1000, "ab232", 250);
      Privado privado1 = new Privado(10000,250,8);
      Comercial comercial1 = new Comercial (20000, 250,50);
      Carreta carreta1 = new Carreta(100);
      auto1.MostarPrecio();
      auto1.MostarPatente();
      Console.WriteLine(Gestion.MostrarImpuestoNacional(auto1));
      privado1.MostarPrecio();
      Console.WriteLine(Gestion.MostrarImpuestoNacional(privado1));
      carreta1.MostarPrecio();
      Console.WriteLine(Gestion.MostrarImpuestoProvincial(carreta1));
      comercial1.MostarPrecio();
      Console.WriteLine(Gestion.MostrarImpuestoProvincial(comercial1));
      privado1.MostarPrecio();
      Console.WriteLine(Gestion.MostrarImpuestoProvincial(privado1));
      Console.Read();
    }
  }
}
