﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio00
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombre;
            int edad;
            Console.WriteLine("hola mundo");
            Console.ReadLine();
            Console.Write("Ingrese su nombre: ");
            nombre = Console.ReadLine();
            Console.Write("Ingrese su edad: ");
            edad = int.Parse (Console.ReadLine());
            Console.WriteLine("Su nombre es:{0} \nSu edad es: {1}",nombre,edad);
            Console.ReadLine();
        }
    }
}
