using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace EntidadesParte1
{
  public class Deposito <T>
  {
    private int _capacidadMaxima;
    private List<T> _lista;

    public Deposito(int capacidad)
    {
      this._capacidadMaxima = capacidad;
      this._lista = new List<T>(this._capacidadMaxima);
    }
    public static bool operator +(Deposito <T> d, T a)
    {
      bool valor = false;
      if (d._lista.Count < d._capacidadMaxima)
      {
        d._lista.Add(a);
        valor = true;
      }
      return valor;
    }
    private int GetIndice(T a)
    {
      int valor = -1;
      int contador = 0;
      foreach (T item in this._lista)
      {
        if (item.Equals(a))
        {
          valor = contador;
          break;
        }
        contador++;
      }
      return valor;
    }
    public static bool operator -(Deposito <T> d, T a)
    {
      bool valor = false;
      int indice = d.GetIndice(a);
      if (indice != -1)
      {
        d._lista.RemoveAt(indice);
        valor = true;
      }
      return valor;
    }
    public bool Agregar(T a)
    {
      return this + a;
    }
    public bool Remover(T a)
    {
      return this - a;
    }
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("capacidad :" + this._capacidadMaxima);
      foreach (T item in this._lista)
      {
        sb.AppendLine(item.ToString());
      }
      return sb.ToString();
    }
    public bool Guardar(string path)
    {
      bool valor = false;
      try
      {
        using (StreamWriter sw = new StreamWriter(path, true))
        {
          sw.WriteLine(this.ToString());
          valor = true;
        }
      }
      catch (Exception)
      {
        valor = false;
      }
      return valor;
    }
    public bool Recuperar(string path)
    {
      bool valor = false;
      string recuperado;
      using (StreamReader sr = new StreamReader(path, true))
      {
        recuperado = sr.ReadToEnd();
        Console.WriteLine(recuperado);
        valor = true;
      }
      return valor;
    }
  }
}
