using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace SQL
{
  class Program
  {
    static void Main(string[] args)
    {
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "select * from Televisores";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
      Televisor tele3 = new Televisor(111, "Lenovo", 122990, 55, "España");
      tele3.Insertar();
      List < Televisor > televisores = new List<Televisor>();
      conexion.Open();
      SqlDataReader lector = comando.ExecuteReader();
      

      while (lector.Read())
      {
        Console.WriteLine(lector[0]+ "-"+ lector[1]+ "-" + lector[2] +"-" + lector[3] + "-" + lector[4]);
        televisores.Add(new Televisor(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3),lector.GetString(4)));
      }
      
      conexion.Close();
      XmlSerializer serializer = new XmlSerializer(typeof(List<Televisor>));
      XmlTextWriter textWriter = new XmlTextWriter("televisores.xml", Encoding.UTF8);
      XmlTextReader textReader = new XmlTextReader("televisores.xml");
      serializer.Serialize(textWriter, televisores);
      textWriter.Close();
      
      List<Televisor> l = (List<Televisor>)serializer.Deserialize(textReader);
      
      conexion.Open();
      lector = comando.ExecuteReader();
      DataTable table = new DataTable("televisores");
      table.Load(lector);
      table.WriteXmlSchema("televisores_Esquema.xml");
      table.WriteXml("televisores_DT.xml");
      DataTable dataT = new DataTable();
      dataT.ReadXmlSchema("televisores_Esquema.xml");
      dataT.ReadXml("televisores_DT.xml");
      

      Console.Read();
    }
  }
}
