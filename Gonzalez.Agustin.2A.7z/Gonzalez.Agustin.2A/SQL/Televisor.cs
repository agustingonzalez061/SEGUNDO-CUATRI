using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace SQL
{
  public class Televisor
  {
    public int id;
    public string marca;
    public double precio;
    public int pulgada;
    public string pais;

    public Televisor(int id, string marca, double precio, int pulgada, string pais)
    {
      this.id = id;
      this.marca = marca;
      this.precio = precio;
      this.pulgada = pulgada;
      this.pais = pais;
    }
    public Televisor()
    {
    }
    public bool Insertar ()
    {

      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

      SqlCommand comando = new SqlCommand();
      comando.CommandText = "Insert into televisores " + "values" + "(" + this.id + ",'" + this.marca + "'," + this.precio + "," + this.pulgada + ",'"+this.pais +"')";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
        Console.WriteLine("Agregado");
        return true;
      }
      catch (Exception)
      {
        Console.WriteLine("No agregado");
        return false;
        throw;
      }
    }
  }
}
