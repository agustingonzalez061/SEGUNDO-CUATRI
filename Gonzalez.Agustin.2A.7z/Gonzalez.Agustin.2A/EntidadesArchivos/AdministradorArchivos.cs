using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace EntidadesArchivos
{
    public static class AdministradorArchivos
    {
        public static bool Escribir (string path, string b)
        {
            bool valor = false;
            try
            {
                using (StreamWriter sw = new StreamWriter(path, true))
                {
                    sw.WriteLine(b);
                    valor = true;
                }
            }
            catch (Exception)
            {
                valor = false;
            }
             return valor;
        }
        public static bool Leer (string path, out string b)
        {
            bool valor = false;
            string recuperado;
            using (StreamReader sr = new StreamReader(path, true))
            {
                 recuperado = sr.ReadToEnd();
                 b = recuperado;
                 valor = true;
            }
            return valor;
        }
    }
}
