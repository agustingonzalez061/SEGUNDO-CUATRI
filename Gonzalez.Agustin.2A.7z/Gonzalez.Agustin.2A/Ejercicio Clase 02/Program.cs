﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Ejercicio_Clase_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Sello.mensaje = "HOLA";
            Console.WriteLine("Este es el mensaje {0}", Sello.Imprimir());
            Sello.Borrar();
            Console.WriteLine("Este es el mensaje {0}", Sello.Imprimir());
            Sello.mensaje = "CHAU";
            Sello.color = ConsoleColor.DarkCyan;
            Sello.ImprimirEnColor();
            Console.WriteLine("Este es el mensaje {0}", Sello.Imprimir());
            Console.Read();

        }
    }
}
