﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio 03";
            int i;
            int primo;
            int num;

            Console.WriteLine("Ingrese un numero");
            num = int.Parse(Console.ReadLine());
            while (num < 0)
            {
                Console.Write("ERROR REINGRESE NUMERO :");
                num = int.Parse(Console.ReadLine());
            }
            for (i = 0; i < num; i++)
            { }
        }
    }
}
