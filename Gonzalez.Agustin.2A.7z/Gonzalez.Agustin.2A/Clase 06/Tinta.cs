using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase05
{
  class Tinta
  {
    #region Atributos
    private ConsoleColor color;
    private ETipoTinta tinta;
    #endregion
    #region Contructor

    public Tinta()
    {
      this.tinta = ETipoTinta.Comun;
      this.color = ConsoleColor.Black;
    }
    public Tinta(ETipoTinta b) : this()
    {
      this.tinta = b;
    }
    public Tinta(ETipoTinta b, ConsoleColor c) : this(b)
    {
      this.color = c;
    }
    #endregion

    #region metodos
    public static string Mostrar(Tinta a)
    {
      if (!object.Equals(a, null))
      {
        return a.Mostrar();
      }
      return "--";
    }
    private string Mostrar()
    {
      return this.color + " " + this.tinta;
    }

    #endregion

    public void EstablecerValor(ETipoTinta a)
    {
      this.tinta = a;
    }
    public void EstablecerValor(ConsoleColor a)
    {
      this.color = a;
    }
    #region SobreCarga
    public static bool operator ==(Tinta a, Tinta b)
    {
      bool valor = false;
      if (!object.Equals(a, null)&& !object.Equals(b, null))
      {
        if (a.color == b.color && a.tinta == b.tinta)
        {
          valor = true;
        }
      }
      return valor;
    }

    public static bool operator !=(Tinta a, Tinta b)
    {

      return !(a == b);
    }
    #endregion
  }
}
