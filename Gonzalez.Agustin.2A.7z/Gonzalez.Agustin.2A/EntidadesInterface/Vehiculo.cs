using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesInterface
{
  public abstract class Vehiculo
  {
    protected double _precio;

    public void MostarPrecio()
    {
      Console.WriteLine("El precio del vehiculo es: {0}", _precio);
    }
    public Vehiculo (double precio)
    {
      this._precio = precio;
    }
  }
}
