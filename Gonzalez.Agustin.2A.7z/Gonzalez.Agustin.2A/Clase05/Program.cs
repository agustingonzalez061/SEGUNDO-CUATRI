using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase05;
namespace Clase05
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.Title = "CLASE 05";
      Tinta obj1 = new Tinta();
      Tinta obj2 = new Tinta(ETipoTinta.Comun);
      Tinta obj3 = new Tinta(ETipoTinta.Comun,ConsoleColor.DarkMagenta);

      Console.WriteLine(Tinta.Mostrar(obj1));
      Console.WriteLine(Tinta.Mostrar(obj2));
      Console.WriteLine(Tinta.Mostrar(obj3));
      if (obj1 != obj2)
      {
        Console.WriteLine("SON DISTINTOS");
      }
      else
      {
        Console.WriteLine("SON IGUALES");
      }
      Pluma obj4 = new Pluma();
      Pluma obj5 = new Pluma("Bic");
      Pluma obj6 = new Pluma("Hola",45);
      Pluma obj7 = new Pluma("Hola", 45,obj3);

      Console.WriteLine(obj4);
      Console.WriteLine(obj5);
      Console.WriteLine(obj6);
      Console.WriteLine(obj7);
      Console.ReadLine();
    }
  }
}
