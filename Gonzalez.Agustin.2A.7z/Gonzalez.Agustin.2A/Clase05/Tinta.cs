using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase05
{
  class Tinta
  {
    #region
    private ConsoleColor color;
    private ETipoTinta tinta;
    #endregion
    #region Contructor

    public Tinta()
    {
      this.tinta = ETipoTinta.Comun;
      this.color = ConsoleColor.Black;
    }
    public Tinta(ETipoTinta b) : this()
    {
      this.tinta = b;
    }
    public Tinta(ETipoTinta b, ConsoleColor c) : this(b)
    {
      this.color = c;
    }
    #endregion

    #region metodos
    public static string Mostrar(Tinta a)
    {

      return a.Mostrar();
    }
    private string Mostrar()
    {
      return this.color + " " + this.tinta.ToString();
    }

    #endregion

    public void EstablecerValor(ETipoTinta a)
    {
      this.tinta = a;
    }
    public void EstablecerValor(ConsoleColor a)
    {
      this.color = a;
    }

    public static bool == (Tinta a, Tinta b)
      {
}
  }
}
