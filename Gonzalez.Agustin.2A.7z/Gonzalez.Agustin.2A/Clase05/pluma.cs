using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase05
{
  class Pluma
  {
    #region Atributos
    private string _marca;
    private int _Cantidad;
    private Tinta _tinta;
    #endregion
    #region Contructor
    public static implicit operator string (Pluma pluma)
    {
      if (!object.Equals(pluma, null))
      {
        return pluma.Mostrar();
      }
      return "--";
    }

    private string Mostrar()
    {
      string retorno = " ";
      retorno = retorno + this._marca;
      retorno = retorno + " ";
      retorno = retorno + this._Cantidad;
      retorno = retorno + " ";
      retorno = retorno + Tinta.Mostrar(this._tinta);
      return retorno;
    }

    public Pluma()
    {
      this._Cantidad = 0;
      this._marca = "Sin marca";
      this._tinta = null;
    }
    public Pluma(string marca) : this()
    {
      this._marca = marca;
    }
    public Pluma(string marca, int cant) : this(marca)
    {
      this._Cantidad = cant;
    }
    public Pluma(string marca, int cant, Tinta tinta) : this(marca,cant)
    {
      this._tinta = tinta;
    }
    #endregion
    #region SobreCarga
    public static bool operator ==(Pluma obj1,Tinta obj2)
    {
      bool valor = false;
      if (!object.Equals(obj1, null) && !object.Equals(obj2, null))
      {
        if (obj1._tinta == obj2)
        {
          valor = true;
        }
      } 
      return valor;
    }

    public static bool operator !=(Pluma obj1, Tinta obj2)
    {

      return !(obj1 == obj2);
    }

    public static bool operator +(Pluma obj1, Tinta obj2)
    {
      bool retorno = false;
      int resultado;
      if (obj1 == obj2 && obj1._Cantidad < 100 || obj2 == null)
      {
        resultado =obj1._Cantidad - 100;
        obj1._Cantidad += resultado;
        retorno = true;
      }
      return retorno;
    }

    #endregion
  }
}
