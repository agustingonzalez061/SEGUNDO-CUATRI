public delegate void ActualizarNombrePorDelegado(string n);
