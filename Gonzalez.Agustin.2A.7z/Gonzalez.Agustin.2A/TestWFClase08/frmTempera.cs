using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace TestWFClase08
{
  public partial class frmTempera : Form
  {
    private Tempera _miTempera;
    public Tempera MiTempera { get { return this._miTempera; } }
    public frmTempera()
    {
      InitializeComponent();
      foreach (ConsoleColor item in Enum.GetValues(typeof(ConsoleColor)))
      {
        this.comboBox2.Items.Add(item);
      }
      this.comboBox2.SelectedItem = ConsoleColor.Yellow;
      this.comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

      this.MaximizeBox = false;
      this.MinimizeBox = false;

    }

    private void frmTempera_Load(object sender, EventArgs e)
    {

    }

    private void label1_Click(object sender, EventArgs e)
    {

    }

    private void button1_Click(object sender, EventArgs e)
    {
      ConsoleColor color = (ConsoleColor)this.comboBox2.SelectedItem;
      string marca = this.textBox2.Text;
      sbyte cantidad =sbyte.Parse(this.textBox1.Text);
      this._miTempera = new Tempera(marca,cantidad,color);
      this.DialogResult = DialogResult.OK;
    }

    private void button2_Click(object sender, EventArgs e)
    {
      this.DialogResult = DialogResult.Cancel;

      foreach (Control item in this.Controls)
      {
        if (item is TextBox || item is ComboBox)
          item.Text = "";
      }
    }
    public frmTempera(Tempera t1):this()
    {
      this._miTempera = t1;
      MessageBox.Show("En el Constructor");
    }
  }
}
