using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace TestWFClase08
{
  public partial class Form1 : Form
  {
    Paleta _miPaleta;
    public Form1()
    {
      InitializeComponent();
      this._miPaleta = 5;
      this.groupBox1.Text = "Paleta de colores";
      this.textBox1.Multiline = true;
      this.button1.Text = "+";
      this.button2.Text = "-";
    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void groupBox1_Enter(object sender, EventArgs e)
    {

    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {

    }

    private void agregarPaletaToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.groupBox1.Visible = true;
      this.agregarPaletaToolStripMenuItem.Enabled = false;
    }

    private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
    {

    }

    private void button1_Click(object sender, EventArgs e)
    {
      frmTempera frm = new frmTempera();

      frm.StartPosition = FormStartPosition.CenterScreen;
      DialogResult rta = frm.ShowDialog();

      if(rta == DialogResult.OK)
        this._miPaleta += frm.MiTempera;
      this.textBox1.Text = (string)this._miPaleta;
    }
  }
}
