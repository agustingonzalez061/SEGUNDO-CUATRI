using System;
using System.Collections.Generic;
using System.Text;
using Entidades.Clase07;

namespace Entidades.Clase07
{
    public class Paleta
    {
    #region Atributos
    private Tempera[] _colores;
    private int _CantMaximaElementos;
    #endregion
    #region Constructor
    public Paleta() : this(5)
    {
    }
    public Paleta(int cant)
    {
      this._CantMaximaElementos = cant;
      this._colores = new Tempera[this._CantMaximaElementos];
    }
    #endregion
    #region Metodos
    private string Mostrar()
    {
      string retorno = "";
      retorno += this._CantMaximaElementos;
      foreach (Tempera item in this._colores)
      {
        if(!object.Equals(item, null))
        retorno += item + "\r\n";
      }

      return retorno;

    }
    public static explicit operator string(Paleta obj1)
    {

      return obj1.Mostrar();
      
    }
    public static implicit operator Paleta(int n)
    {
      return new Paleta(n);
    }
    private int encontrarIndice()
    {
      int i;
      int retornoIndice = -1;
      for (i = 0; i < this._CantMaximaElementos; i++)
      {
        if (this._colores.GetValue(i) == null)
        {
          retornoIndice = i;
          break;
        }
      }
      return retornoIndice;
    }
    private int encontrarIndice(Tempera obj1)
    {
      int i;
      int retornoIndice = -1;
      for (i = 0; i < this._CantMaximaElementos; i++)
      {
        if (this._colores.GetValue(i) == null)
        {
          if (this._colores[i] == obj1)
          {
            retornoIndice = i;
            break;
          }
        }
      }
      return retornoIndice;
    }
    #endregion
    #region SobreCarga
    public static bool operator ==(Paleta obj1, Tempera obj2)
    {
      int i;
      bool retorno = false;
      for (i = 0; i < obj1._CantMaximaElementos; i++)
      {
        if (obj1._colores.GetValue(i) != null)
        {
          if (obj1._colores[i] == obj2)
          {
            retorno = true;
          }
        }
      }
      return retorno;
    }
    public static bool operator !=(Paleta obj1, Tempera obj2)
    {
      return !(obj1 == obj2);
    }
    public static Paleta operator + (Paleta obj1,Tempera obj2)
    {
      bool retorno = false;
      int indice;
      if (obj1 == obj2)
      {
        indice = obj1.encontrarIndice(obj2);
        obj1._colores[indice] += obj2;
      }
      else
      {
        indice = obj1.encontrarIndice();
        if (indice > -1)
        {
          obj1._colores[indice] = obj2;
        }
      }
      return obj1;
    }
    public static Paleta operator -(Paleta obj1, Tempera obj2)
    {
      int i;
      sbyte auxTemp;
      sbyte auxPale;
      if (obj1 == obj2)
      {
        i = obj1.encontrarIndice(obj2);
        auxPale = (sbyte)obj1._colores[i];
        auxTemp = (sbyte)obj2;
        if ((auxPale -auxTemp) <= 0)
        {
          obj1._colores[i] = null;
        }
        else
        {
          obj1._colores[i] += (sbyte)(auxTemp * (-1)); 
        }
      }
      return obj1;
    }
    public int cantidadDeTemp
    {
      get
      {
        return this._colores.GetLength(0);
      }

    }
    #endregion
    #region indexador
    #endregion
    public Tempera this[int indice]
    {
        get
        {
          if (indice == this._colores.GetLength(0) || indice < 0)
          {
            return null;
          }
        else
        {
          return this._colores[indice];
        }
        }
         set
        {
        if (indice >= 0 && indice == this._colores.GetLength(0))
        {
          this._colores[indice] = value;
        }
        else if (indice == this._colores.GetLength(0))
        {
          this._colores = this + indice;
          this[indice] = value;
        }
        }
    }
    public static Tempera[] operator +(Paleta pale, int indice)
    {
      int i = indice >= pale._colores.GetLength(0) ? ++indice : --indice;

      Tempera[] aux = new Tempera[i];

      pale._colores.CopyTo(aux, 0);

      return aux;

    }
  }
}
