using System;
using System.Collections.Generic;
using System.Text;

namespace EntidadesParte2
{
    public class Cocina
    {
    private int _codigo;
    private bool _esIndustrial;
    private double _precio;

    public int Codigo
    {
      get
      {
        return _codigo;
      }
    }
    public bool EsIndustrial
    {
      get
      {
        return _esIndustrial;
      }
    }
    public double precio
    {
      get
      {
        return _precio;
      }
    }
    public Cocina(int codigo, double precio, bool esIndustrial)
    {
      this._esIndustrial = esIndustrial;
      this._codigo = codigo;
      this._precio = precio;
    }
    public static bool operator ==(Cocina obj1, Cocina obj2)
    {
      bool valor = false;
      if (!object.Equals(obj1, null) && !object.Equals(obj2, null))
      {
        if (obj1.Codigo == obj2.Codigo)
        {
          valor = true;
        }
      }
      return valor;
    }
    public static bool operator !=(Cocina obj1, Cocina obj2)
    {
      return !(obj1 == obj2);
    }
    public override bool Equals(object obj)
    {
      bool flag = false;
      if (obj is Cocina && this == ((Cocina)obj))
      {
        flag = true;
      }
      return flag;
    }
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Codigo : " + this.Codigo);
      sb.AppendLine("");
      sb.AppendLine("Es industrial : " + this.EsIndustrial);
      sb.AppendLine("");
      sb.AppendLine("Precio : " + this.precio);
      sb.AppendLine("");
      sb.AppendLine("---------------------");

      return sb.ToString();
    }
  }
}
