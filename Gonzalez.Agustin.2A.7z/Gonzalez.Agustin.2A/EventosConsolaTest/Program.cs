using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesSQL;

namespace EventosConsolaTest
{
  class Program
  {
    static void Main(string[] args)
    {
      Televisor tv = new Televisor(899, "Lenovo", 25000, 60, "España");
      
      Program program = new Program();
      tv.MiEvento += new MiDelegado(program.PruebaEventoDos);
      tv.MiEvento += new MiDelegado(PruebaEvento);
      tv.EventoTv += new DelegadoTv(program.Manejador);
      tv.Insertar();
      Televisor.TraerTodos();
      Televisor.TraerUno(158);
      Console.Read();
    }
    public static void PruebaEvento ()
      {
      Console.WriteLine("Se inserto un registro en la basse de datos");
      }
    public void PruebaEventoDos()
    {
      Console.WriteLine("Estoy en el segundo metodo de los delegados");
    }
    public void Manejador (Televisor tv,TvEventsArgs fecha)
    {
      Console.WriteLine(" codigo = " + tv.id + "  marca = " + tv.marca + ", " + "precio = " + tv.precio + ", " + "pulgadas = " + tv.pulgada + ", " + "pais = " + tv.pais+ " , Fecha = " + fecha.Fecha);
    }
  }
}
