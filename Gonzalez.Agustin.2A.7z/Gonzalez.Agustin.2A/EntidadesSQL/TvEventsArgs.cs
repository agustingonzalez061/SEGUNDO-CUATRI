using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesSQL
{
  public class TvEventsArgs : EventArgs

  {
    public DateTime Fecha
    {
      get;
      set;
    }
  }
}
